''' 
We empty weight (lb)
Vmax maximum velocity (knots)
Q production quantity
FTA number of flight test aircraft (typically 2-6)
Neng total prodcution quantity times number of engines per aircraft
Tmax engine maximum thrust (lb)
T_turbine_inlet turbine temperatur (Rankine)
Cavionics avionics cost
'''
# hourly rates $ (using inflation factor)
# format; 1986_rate * inflation_factor_1986to2024
F_in_f = 1.831 # inflation_factor_1986to2024: 183.21%; SOURCE:USINFLATIONCALCULATOR.COM
Re = 59.10*F_in_f # engineering
Rt = 60.70*F_in_f # tooling
Rq = 55.40*F_in_f # quality control
Rm = 50.10*F_in_f # manufacturing

# Engineering Hours
def Eng_hrs(We, Vmax, Q):
    He = 4.86*(We**0.777)*(Vmax**0.894)*(Q**0.163)
    return He 

# Tooling Hours
def Tool_hrs(We, Vmax, Q):
    Ht = 5.99 * (We**0.777)*(Vmax**0.696)*(Q**0.263)
    return Ht 

# Manufacturing Hours
def Manu_hrs(We, Vmax, Q):
    Hm = 7.37*(We**0.82)*(Vmax*0.484)*(Q**0.641)
    return Hm

# Quality Control = Hq
# constant * Manu_hrs
# where the constant = 0.076 for a cargo plane
# or constant =0.133 for any other a/c

Hq = 0.076 * Manu_hrs(23,43,23)

# Devel Support Cost
def devel_sup_cost(We, Vmax):
    C_D = 45.42*(We**0.630)*(Vmax**1.3)
    return C_D

# flight test cost
def flt_test_cost(We, Vmax, FTA):
    C_F = 1243.03*(We**0.325)*(Vmax**0.822)*(FTA**1.21)
    return C_F

# manufacturing materials cost
def manu_mat_cost(We, Vmax, Q):
     C_M = 11.0*(We**0.921)*(Vmax**0.621)*(Q**0.799)
     return C_M

# engineering production cost
def prod_cost(Tmax, Mmax, T_turbine_inlet):
    Ceng = 1548*((0.043*Tmax)+(243.25*Mmax)+(0.969*T_turbine_inlet)-2228)
    return Ceng 

def RDTE_Flyaway(He, Re, Ht, Rt, Hm, Rm, Hq, Rq, C_D, C_F, C_M, Ceng, Neng, Cavionics):
    RDTEFlyaway = (He*Re) + (Ht*Rt) + (Hm*Rm)+ (Hq*Rq) + C_D + C_F + C_M + (Ceng*Neng) + Cavionics
    return RDTEFlyaway


# importing libraries
from math import exp, pi

# q is dynamic pressure
#rho = 1.225 #kg/m^3 @ sea level
def dyn_press(rho,vel):
    
    q = 0.5*rho*(vel**2)

    return q

# A is Aspect Ratio
def aspect_ratio(b,S):
    
    A = (b**2)/(S) # b is span and S is surface area

    return A

# W_S wingloading

# L_D lift to drag ratio fxn
def L_D_cruise(q,CD_0,W_S,A,e):

    l_d = 1/((q*CD_0)/(W_S))+((W_S)*(1/(q*pi*A*e)))

    return l_d

# cruise mission leg for jet fxn
def CRUISE(ra_nge, s_f_c, vel, L_D):

    """A function to calculate the cruise

    Args:
        range_ (int): a distance in feet as a unit
        s_f_c (float): specific fuel consumption rate (per second)
        vel (float): the velocity of the aircraft (ft/s)
        L_D (float): lift to drag ratio

    Returns:
        returns the weight fraction (float)
    """

    wf_wi_C = exp(-(ra_nge*s_f_c)/(vel*L_D))
    return wf_wi_C

#loiter mission leg for jet fxn
def LOITER(en_dure, s_f_c, L_D):

    """A function to calculate the loiter

    Args:
        endure (float): time to cover a distance
        s_f_c (float): specific fuel consumption rate (per second)
        L_D (float): lift to drag ratio

    Returns:
        returns the weight fraction (float)
    """

    wf_wi_L = exp(-(en_dure*s_f_c)/(L_D))
    return wf_wi_L


# using the mission profile of a fighter jet
# 0-1-2-3-4-5-6-7-8-9-10-11
#initial data
w_crew = 100
w_fixed_pay = 5680
w_drop_pay = 1895

w_payload = w_fixed_pay + w_drop_pay 

#initial weight guess
w0_guess = 4*w_payload 



# Engine Start, Taxi and Takeoff mission leg; 0-1. w1_w0
w1_w0 = 0.97  # ranges between 0.97 - 0.99
w0_1 = (1 -w1_w0)*w0_guess
w1 = w0_guess - w0_1

# climb and accelerate mission leg; 1-2. w2_w1
# assuming a subsonic climb, where M is the final mach number in that mission leg
M1_2 = 0.85
w2_w1 = 1.0065 - 0.0325*M1_2
w1_2 = (1- w2_w1)*w1
w2 = w1 - w1_2 


# first cruise mission leg; transonic: 2-3. w3_w2
# cruising altitude = 2.5km
M_cruise = 0.85
R_cruise = 370400 #m =200nm
V_cruise = 280.95 #m/s
C_cruise = 0.00002222 #/s
rho_cruise = 0.957 #kg/m^3
C_d0_cruise = 0.0202
w_s_cruise = 4013.09 #N/m^2 (409.2kg/m^2)
q_cruise = dyn_press(rho_cruise,V_cruise)
l_d_cruise = L_D_cruise(q_cruise,C_d0_cruise,w_s_cruise,A=3,e=0.9086)
w3_w2 = CRUISE(R_cruise,C_cruise,V_cruise,l_d_cruise) 
w2_3 = (1 - w3_w2)*w2
w3 = w2 - w2_3

# first descent mission leg; estimated historically 0.990 - 0.995: 3-4
# w4_w3
# w4_w3 = 1
# fuel consumed during descent leg is ignored, 
w3_4 = 0 
w4 = w3 

# dash supersonic w5_w4
# dash_altitude = 1.5km
M_dash = 1.05
R_dash = 92600 #m (50nm)
V_dash = 353.22
C_dash = 0.0006833 #/s
rho_dash = 1.112 #kg/m^3
C_d0_dash = 0.0444
w_s_dash = 3781.53 #N/m^2 (385.6kg/m^2)
q_dash = dyn_press(rho_dash,V_dash)
l_d_dash = L_D_cruise(q_dash,C_d0_dash,w_s_dash,A=3,e=0.9086)
w5_w4 = CRUISE(R_dash,C_dash,V_dash,l_d_dash)
w4_5 = (1 - w5_w4)*w4
w5 = w4 - w4_5

#combat leg w6_w5
#data SFC combat, thrust loading, time for combat
C_combat = 0.0002222 #m
T_w_combat = 0.1174
d_combat = 1200 #s(20mins) 
w_drop_pay = 1895 #kg
w6_w5 = 1 - (C_combat*T_w_combat*d_combat)
w5_6 = (1- w6_w5)*w5
w6 = w5 -w5_6 - w_drop_pay

#unaccelerated climg leg w7_w6
w7_w6 = 0.986
w6_7 = (1 - w7_w6)*w6
w7 = w6 - w6_7

# return cruise leg w8_w7
R_cruise_R = 463000 #m
V_cruise_R = 179.66 #m/s
C_cruise_R = 0.0002222 #/s
rho_cruise_R = 0.414 #kg/m^3
C_d0_cruise_R = 0.0193 
w_s_cruise_R = 2853.91 #N/m^2
q_cruise_R = dyn_press(rho_cruise_R,V_cruise_R)
l_d_cruise_R = L_D_cruise(q_cruise_R,C_d0_cruise_R,w_s_cruise_R,A=3,e=0.9086)
w8_w7 = CRUISE(R_cruise_R,C_cruise_R,V_cruise_R,l_d_cruise_R)
w7_8 = (1 - w8_w7)*w7
w8 = w7 - w7_8

# loiter leg: w9_w8
Endure_loiter = 2700 #s
V_loiter = 136.19 #m/s
C_loiter = 0.0002222 #/s
rho_loiter = 0.414 #kg/m^3
C_d0_loiter = 0.0193
w_s_loiter = 2702.65 #N/m^2
q_loiter = dyn_press(rho_loiter,V_loiter)
l_d_loiter = L_D_cruise(q_loiter,C_d0_loiter,w_s_loiter,A=3,e=0.9086)
w9_w8 = LOITER(Endure_loiter,C_loiter,l_d_loiter)
w8_9 = (1 - w9_w8)*w8
w9 = w8 - w8_9

#fuel weight in descent leg befor landing
w9_10 = 0
w10 = w9 

#approah and land leg: w11_w10
w11_w10 = 0.995
w10_11 = (1 - w11_w10)*w10
w11 = w10 - w10_11

# total fuel used in legs
w_fm = w0_1 + w1_2 + w2_3 + w3_4 + w4_5 + w5_6 + w6_7 + w7_8 + w8_9 + w9_10 + w10_11

rff = 0.06 #(6%)
W_fuel = (1 + rff)* w_fm

# empty weight fraction for a jet engine aircraft
# a = -0.02
# b = 2.16
# C1 = -0.10
# A = 3
# w0 = 2.204*w0 #lb
# C2 = 0.20
# C3 = 0.04
# C4 = -0.10
# C5 = 0.08
# T_w0 = 0.09992 # 0.98N/kg
# w0_S = 865.796 #4226.817 N/m^2
# M_max = 2.05
# k_vs = 1
# we_w0 = (a + ((b)* ((b)*(w0**C1))*(A**C2)*(T_w0**C3)*(w0_S**c4)*(M_max**C5)))*K_vs 
while True:
    we_w0 = -0.02 + 1.221*(w0_guess**-0.10)
    w_empty = we_w0 * w0_guess
    w0 = w_crew + w_fixed_pay + w_drop_pay + W_fuel + w_empty 
    err = abs(w0 - w0_guess)
    if err <= 10**-4:
        w_tkoff = w0
        break 
    else:
        w0_guess = (w0_guess + w0)/2

print(w_tkoff)

# we_w0 = -0.02 + 1.221*(w0_guess**-0.10)
# w_empty = we_w0 * w0_guess
# w0 = w_crew + w_fixed_pay + w_drop_pay + W_fuel + w_empty 
# print(w0)

#fuselage length
a_fl = 0.67
C = 0.43
fuselage_length = a_fl* (w_tkoff**C)
print("fuselage length =",fuselage_length)
# calculating for the mission weight in refined sizing of a seaplane 
# Wf_i = (1-(Wi/Wi_1))*Wi 
# total mission fuel, W_fm = E_Wf_i; E here is representing the greek summation symbol
# total aircraft fuel, Wf = 1.06(E_Wf_i)

# algorithm 
# know the mission segements
# calculate the mission leg fuel fractions
# find the fuel left after each mission leg
# use historical data for start and takeoff,descent,landing and taxiback

# Estimation of mission leg weight fractions
# warm-up, TO and Landing weight fractions - estimated using weight fractions
# fuel consumed (and distance travelled) in Descent segments - ignored
# warmup and Take-off = 0.970
# unaccelerated climb = 0.985
# descent = 1
# approach and landing = 0.995

# importing libraries
from math import exp, pi

# q is dynamic pressure
#rho = 1.225 #kg/m^3 @ sea level
def dyn_press(rho,vel):
    
    q = 0.5*rho*(vel**2)

    return q

# A is Aspect Ratio
def aspect_ratio(b,S):
    
    A = (b**2)/(S) # b is span and S is surface area

    return A

# W_S wingloading

# L_D lift to drag ratio fxn
def L_D_cruise(q,CD_0,W_S,A,e):

    l_d = 1/((q*CD_0)/(W_S))+((W_S)*(1/(q*pi*A*e)))

    return l_d

# cruise mission leg for jet fxn
def CRUISE(ra_nge, s_f_c, vel, L_D):

    """A function to calculate the cruise

    Args:
        range_ (int): a distance in feet as a unit
        s_f_c (float): specific fuel consumption rate (per second)
        vel (float): the velocity of the aircraft (ft/s)
        L_D (float): lift to drag ratio

    Returns:
        returns the weight fraction (float)
    """

    wf_wi_C = exp(-(ra_nge*s_f_c)/(vel*L_D))
    return wf_wi_C

#loiter mission leg for jet fxn
def LOITER(en_dure, s_f_c, L_D):

    """A function to calculate the loiter

    Args:
        endure (float): time to cover a distance
        s_f_c (float): specific fuel consumption rate (per second)
        L_D (float): lift to drag ratio

    Returns:
        returns the weight fraction (float)
    """

    wf_wi_L = exp(-(en_dure*s_f_c)/(L_D))
    return wf_wi_L

# using the mission profile 
# 0-1-2-3-4-5-6
# 0-1 warm up tkaeoff
# 1-2 accelerated climb
# 2-3 cruise
# 3-4 loiter 
# 4-5 return cruise
# 5-6 descend
# 6-7 apporach and land 

A = 8
e = (1.78 * (1 - 0.045 * (A ** 0.68))) - 0.64

#initial data
w_crew = 100
w_fixed_pay = 5680
w_drop_pay = 35000 #kg

w_payload = w_fixed_pay + w_drop_pay 

#initial weight guess
w0_guess = 4*w_payload 


# Engine Start, Taxi and Takeoff mission leg; 0-1. w1_w0
w1_w0 = 0.97  # ranges between 0.97 - 0.99
w0_1 = (1 -w1_w0)*w0_guess
w1 = w0_guess - w0_1

# climb and accelerate mission leg; 1-2. w2_w1
# assuming a subsonic climb, where M is the final mach number in that mission leg
M1_2 = 0.1
w2_w1 = 1.0065 - 0.0325*M1_2
w1_2 = (1- w2_w1)*w1
w2 = w1 - w1_2 

# 1st cruise mission leg; subsonic: 2-3. w3_w2; 
# cruising altitude = 77 m
M_cruise = 0.78
R_cruise = 370400 #m =200nm
V_cruise = 267 #m/s
C_cruise = 0.0001388889 #/s (0.5/hr)
rho_cruise = 1.225 #kg/m^3
C_d0_cruise = 0.017
w_s_cruise = 4370 #N/m^2 (445.6kg/m^2)
q_cruise = dyn_press(rho_cruise,V_cruise)
l_d_cruise = L_D_cruise(q_cruise,C_d0_cruise,w_s_cruise,A,e)
w3_w2 = CRUISE(R_cruise,C_cruise,V_cruise,l_d_cruise) 
w2_3 = (1 - w3_w2)*w2
w3 = w2 - w2_3


# loiter leg: 3-4: w4_w3
Endure_loiter = 1800 #s
V_loiter = 136.19 #m/s
C_loiter = 0.00011111 #/s (0.4/hr)
rho_loiter = 1.225 #kg/m^3
C_d0_loiter = 0.017
w_s_loiter = 4370 #N/m^2 (445.6kg/m^2)
q_loiter = dyn_press(rho_loiter,V_loiter)
l_d_loiter = L_D_cruise(q_loiter,C_d0_loiter,w_s_loiter,A,e)
w4_w3 = LOITER(Endure_loiter,C_loiter,l_d_loiter)
w3_4 = (1 - w4_w3)*w3
w4 = w3 - w3_4 - w_drop_pay


# return cruise leg w5_w4
R_cruise_R = 463000 #m
V_cruise_R = 267 #m/s
C_cruise_R = 0.0001388889 #/s (0.5/hr)
rho_cruise_R = 1.225 #kg/m^3
C_d0_cruise_R = 0.017 
w_s_cruise_R = 4370 #N/m^2 (445.6kg/m^2)
q_cruise_R = dyn_press(rho_cruise_R,V_cruise_R)
l_d_cruise_R = L_D_cruise(q_cruise_R,C_d0_cruise_R,w_s_cruise_R,A,e)
w5_w4 = CRUISE(R_cruise_R,C_cruise_R,V_cruise_R,l_d_cruise_R)
w4_5 = (1 - w5_w4)*w4
w5 = w4 - w4_5

#fuel weight in descent leg before landing
w5_6 = 0
w6 = w5 

#approah and land leg: w7_w6: 6-7
w7_w6 = 0.995
w6_7 = (1 - w7_w6)*w5
w7 = w6 - w6_7

# total fuel used in legs
w_fm = w0_1 + w1_2 + w2_3 + w3_4 + w4_5 + w5_6 + w6_7

rff = 0.06 #(6%)
W_fuel = (1 + rff)* w_fm

# empty weight fraction for a jet engine aircraft
# a = 0
# b = 0.41
# C1 = -0.01
# A = 8
# w0 = 2.204*w0 #lb
# C2 = 0.10
# C3 = 0.05
# C4 = -0.12
# C5 = 0.18
# hp_w0 = 0.1 #(w0/hp = 10)
# w0_S = 445.6 #kg/m^2 (4370 N/m^2)
# V_max = 200
# we_w0 = (a + ((b)* ((b)*(w0**C1))*(A**C2)*(hp_w0**C3)*(w0_S**c4)*(V_max**C5))) 
while True:
    we_w0 = 0.7447 * (w0_guess**-0.01)
    w_empty = we_w0 * w0_guess
    w0 = w_crew + w_payload + W_fuel + w_empty 
    err = abs(w0 - w0_guess)
    if err <= 10**-4:
        w_tkoff = w0
        break 
    else:
        w0_guess = (w0_guess + w0)/2

print("takeoff weight =",w_tkoff)

# we_w0 = -0.02 + 1.221*(w0_guess**-0.10)
# w_empty = we_w0 * w0_guess
# w0 = w_crew + w_fixed_pay + w_drop_pay + W_fuel + w_empty 
# print(w0)

#fuselage length
a_fl = 0.67
C = 0.43
fuselage_length = a_fl* (w_tkoff**C)
print("fuselage length =",fuselage_length)

# importing libraries
from math import exp, pi

# q is dynamic pressure
#rho = 1.225 #kg/m^3 @ sea level
def dyn_press(rho,vel):
    
    q = 0.5*rho*(vel**2)

    return q

# A is Aspect Ratio
def aspect_ratio(b,S):
    
    A = (b**2)/(S) # b is span and S is surface area

    return A

# W_S wingloading

# L_D lift to drag ratio fxn
def L_D_cruise(q,CD_0,W_S,A,e):

    l_d = 1/((q*CD_0)/(W_S))+((W_S)*(1/(q*pi*A*e)))

    return l_d

# cruise mission leg for jet fxn
def CRUISE(ra_nge, s_f_c, vel, L_D):

    """A function to calculate the cruise

    Args:
        range_ (int): a distance in feet as a unit
        s_f_c (float): specific fuel consumption rate (per second)
        vel (float): the velocity of the aircraft (ft/s)
        L_D (float): lift to drag ratio

    Returns:
        returns the weight fraction (float)
    """

    wf_wi_C = exp(-(ra_nge*s_f_c)/(vel*L_D))
    return wf_wi_C

#loiter mission leg for jet fxn
def LOITER(en_dure, s_f_c, L_D):

    """A function to calculate the loiter

    Args:
        endure (float): time to cover a distance
        s_f_c (float): specific fuel consumption rate (per second)
        L_D (float): lift to drag ratio

    Returns:
        returns the weight fraction (float)
    """

    wf_wi_L = exp(-(en_dure*s_f_c)/(L_D))
    return wf_wi_L

A = 8
e = (1.78 * (1 - 0.045 * (A ** 0.68))) - 0.64

# using the mission profile of a transport jet
# 0-1-2-3-4-5-6
#initial data
w_crew = 80 * 3 #(kg)
w_payload = 42300 #kg


#initial weight guess
w0_guess = 4*w_payload 


# Engine Start, Taxi and Takeoff mission leg; 0-1. w1_w0
w1_w0 = 0.995  # ranges between 0.97 - 0.99
w0_1 = (1 -w1_w0)*w0_guess
w1 = w0_guess - w0_1

# climb and accelerate mission leg; 1-2. w2_w1
# assuming a subsonic climb, where M is the final mach number in that mission leg
M1_2 = 0.1
w2_w1 = 1.0065 - 0.0325*M1_2
w1_2 = (1- w2_w1)*w1
w2 = w1 - w1_2 

# cruise mission leg; transonic: 2-3. w3_w2
# cruising altitude = 2.5km
M_cruise = 0.85
R_cruise = 4173000 #m; 4173km = 2250 nm
V_cruise = 262 #m/s
C_cruise = 0.0001388889 #/s (0.5/hr)
rho_cruise = 0.5258 #kg/m^3
C_d0_cruise = 0.017
w_s_cruise = 4370 #N/m^2 (445.6kg/m^2)
q_cruise = dyn_press(rho_cruise,V_cruise)
l_d_cruise = L_D_cruise(q_cruise,C_d0_cruise,w_s_cruise,A,e)
w3_w2 = CRUISE(R_cruise,C_cruise,V_cruise,l_d_cruise) 
w2_3 = (1 - w3_w2)*w2
w3 = w2 - w2_3

# loiter leg: 3-4: w4_w3
Endure_loiter = 1800 #s (30 mins)
V_loiter = 136.19 #m/s
C_loiter = 0.000111111 #/s (0.4/hr)
rho_loiter = 0.5258 #kg/m^3
C_d0_loiter = 0.017
w_s_loiter = 4370 #N/m^2
q_loiter = dyn_press(rho_loiter,V_loiter)
l_d_loiter = L_D_cruise(q_loiter,C_d0_loiter,w_s_loiter,A,e)
w4_w3 = LOITER(Endure_loiter,C_loiter,l_d_loiter)
w3_4 = (1 - w4_w3)*w3
w4 = w3 - w3_4

# descent mission leg; estimated historically 0.990 - 0.995: 4-5
# w5_w4 = 
# fuel consumed during descent leg is ignored, 
w4_5 = 0 
w5 = w4 

#approah and land leg: w6_w5: 5-6
w6_w5 = 0.992
w5_6 = (1 - w6_w5)*w5
w6 = w5 - w5_6

# total fuel used in legs
w_fm = w0_1 + w1_2 + w2_3 + w3_4 + w4_5 + w5_6 

rff = 0.06 #(6%)
W_fuel = (1 + rff)* w_fm

# empty weight fraction for a jet engine aircraft
# a = 0.32
# b = 0.66
# C1 = -0.13
# A = 3
# w0 = 2.204*w0 #lb
# C2 = 0.30
# C3 = 0.06
# C4 = -0.05
# C5 = 0.05
# T_w0 = 0.24 # 0.98N/kg
# w0_S = 445.6 #kg/m^2 (4370 N/m^2)
# M_max = 0.85
# k_vs = 1
# we_w0 = (a + ((b)* ((b)*(w0**C1))*(A**C2)*(T_w0**C3)*(w0_S**c4)*(M_max**C5)))*K_vs 
while True:
    we_w0 = 0.32 + 0.70836*(w0_guess**-0.13)
    w_empty = we_w0 * w0_guess
    w0 = w_crew + w_payload + W_fuel + w_empty 
    err = abs(w0 - w0_guess)
    if err <= 10**-4:
        w_tkoff = w0
        break 
    else:
        w0_guess = (w0_guess + w0)/2

print("takeoff weight =",w_tkoff)

# we_w0 = -0.02 + 1.221*(w0_guess**-0.10)
# w_empty = we_w0 * w0_guess
# w0 = w_crew + w_fixed_pay + w_drop_pay + W_fuel + w_empty 
# print(w0)

#fuselage length
a_fl = 0.67
C = 0.43
fuselage_length = a_fl* (w_tkoff**C)
print("fuselage lenth =",fuselage_length)