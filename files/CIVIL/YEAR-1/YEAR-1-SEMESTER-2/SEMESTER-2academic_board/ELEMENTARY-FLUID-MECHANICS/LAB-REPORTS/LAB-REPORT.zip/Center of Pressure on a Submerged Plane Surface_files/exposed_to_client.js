if(!window.Scribd) var Scribd = new Object();

Scribd.ServerOptions = {"payments_store_disabled":false,"ad_refresh_engagement_tracking_delay":1200,"sidebar_promo_enabled":false,"facebook_autologin_enabled":true,"disable_trending":false,"ad_refresh_interval":120,"ad_refresh_idle_time_before_inactive":60,"reading_history_scroll_timeout":500,"document_recommendations_test_enabled":true};
