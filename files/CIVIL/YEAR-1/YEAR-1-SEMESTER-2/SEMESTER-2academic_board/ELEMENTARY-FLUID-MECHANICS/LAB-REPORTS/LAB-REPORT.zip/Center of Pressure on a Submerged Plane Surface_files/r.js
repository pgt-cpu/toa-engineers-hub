var ANUT=1;
var ANOO=0;
var ANSR=1;
var ANTID='18j8nmg13v4dkr';
var ANSL='100394';
ANRTXR();
ANDEMO();

