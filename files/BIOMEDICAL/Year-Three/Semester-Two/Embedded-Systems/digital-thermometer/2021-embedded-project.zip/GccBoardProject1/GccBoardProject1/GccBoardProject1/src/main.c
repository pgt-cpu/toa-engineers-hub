

#include <util/delay.h>
#include <avr/interrupt.h>
#include <asf.h>

volatile uint8_t button_pressed = 0;


// TODO: define function for handling button press

void pressButton();

void blinkLED(int times);
void execute_program();



int main(void)

{
	PORTR_DIR |= 0x01;
	PORTE_DIR |= 0x10;
	PORTA_DIR |= 0x08; // Set DISPLAY_RESET as output
	PORTD_DIR |= 0x0B; // Set DISPLAY_RS, USARTD0_SPI_SCK and USARTD0_SPI_MOSI as outputs
	PORTF_DIR |= 0x08;

	PORTF_OUT |= 0x08; // Set DISPLAY_SS high
	PORTA_OUT |= 0x08; // Set DISPLAY_RESET high
	PORTD_OUT |= 0x0B; // Set DISPLAY_RS, USARTD0_SPI_SCK and USARTD0_SPI_MOSI high
	

	
	//PORTE.DIRCLR  |= (1<<5);
	PORTE.PIN5CTRL = (3<<3)| (2<<0);
	PORTE.INT0MASK = PIN5_bm;
	PORTE.INTCTRL = PORT_INT0LVL_LO_gc;
	PMIC.CTRL |= PMIC_LOLVLEN_bm;

	sei();

	
	//turn led off
	PORTR_OUT = 0x01;	
			
	/* Replace with your application code */
	while (1)
	{
		
		
	}
}


ISR(PORTE_INT0_vect){
	button_pressed = 1;
	
	if(button_pressed){
		execute_program();
		exit(1);
		
	}
	
}


void blinkLED(int times){
	// define port direction for Led
	PORTR_DIR = 0x01;
	
	for(int i = 0; i < times; i++){
		PORTR_OUT &= 0x00;
		_delay_ms(1000);
		PORTR_OUT |= 0x01;
		_delay_ms(1000);
	}
}	



	
void execute_program(){
	_delay_ms(1000);
	blinkLED(1);
	gfx_mono_init();
	PORTE.OUT |= 0x10; // Turn DISPLAY_BACKLIGHT on
	_delay_ms(1000);
	gfx_mono_draw_string("BIOMEDICAL ENGINEERING",0,0,&sysfont);
	_delay_ms(3000);
	gfx_mono_draw_string("GROUP 11",0,16,&sysfont);
	_delay_ms(1000);
	blinkLED(2);
	
	//reset lcd
	gfx_mono_init();
	gfx_mono_draw_string("GROUP MEMBERS",0,0,&sysfont);
	gfx_mono_draw_string("GYAMBRAH THEODORA",0,10,&sysfont);
	_delay_ms(1000);
	gfx_mono_draw_string("ADABA GILBERT",0,20,&sysfont);
	_delay_ms(2000);
	gfx_mono_init();
	gfx_mono_draw_string("AGYEMANG BERNARD",0,0,&sysfont);
	_delay_ms(1000);
	gfx_mono_draw_string("ANOKYE TONY",0,10,&sysfont);
	_delay_ms(1000);
	gfx_mono_draw_string("SABUTEY JUDE",0,20,&sysfont);
	_delay_ms(2000);
	gfx_mono_init();
	gfx_mono_draw_string("OPPONG JOSEPHINA",0,0,&sysfont);
	_delay_ms(1000);
	gfx_mono_draw_string("NYARKO HANNAH",0,10,&sysfont);
	_delay_ms(1000);
	gfx_mono_draw_string("MARFO KWADWO",0,20,&sysfont);
	_delay_ms(1000);
	
	
	
	blinkLED(3);
	gfx_mono_init();
	gfx_mono_draw_string("BIOMEDICAL 3, 2021",0,0,&sysfont);
	gfx_mono_draw_string("BYE BYE :)",0,10,&sysfont);
	

	
	
}